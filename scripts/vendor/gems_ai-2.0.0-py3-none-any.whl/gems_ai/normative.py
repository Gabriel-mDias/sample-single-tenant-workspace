"""Focused source gates; snapshot integrity is checked separately."""

from __future__ import annotations

import re
from pathlib import Path

from .errors import GateError


HTTP_CLIENT_IMPORT = re.compile(
    r"\bimport\s*\{[^}]*\bHttpClient\b[^}]*\}\s*from\s*['\"]@angular/common/http['\"]",
    re.DOTALL,
)


def verify_angular(project: Path) -> dict:
    roots = [project / "frontend" / "src", project / "src"]
    sources = sorted({path for root in roots if root.is_dir() for path in root.rglob("*.component.ts")})
    if not sources:
        raise GateError("no Angular component sources found; gate coverage cannot be established")
    violations = [
        str(path.relative_to(project))
        for path in sources
        if HTTP_CLIENT_IMPORT.search(path.read_text(encoding="utf-8"))
    ]
    if violations:
        raise GateError("HttpClient imported in Angular component: " + ", ".join(violations))
    return {"status": "passed", "gate": "angular.http-client-in-component", "files": len(sources)}
