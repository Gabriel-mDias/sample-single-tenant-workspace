from __future__ import annotations

import argparse
import json
import sys
import sysconfig
from pathlib import Path

from . import __version__
from .catalog import Catalog
from .errors import GemsAiError
from .project import apply, check, inspect, planned_files, read_config, rollback
from .normative import verify_angular
from . import rounds


def sdk_root() -> Path:
    checkout = Path(__file__).resolve().parents[2]
    if (checkout / "contract" / "catalog.json").is_file():
        return checkout
    package_path = Path(__file__).resolve()
    candidates = [Path(sysconfig.get_path("data")) / "share" / "gems-ai"]
    candidates.extend(parent / "share" / "gems-ai" for parent in package_path.parents)
    for installed in candidates:
        if (installed / "contract" / "catalog.json").is_file():
            return installed
    raise GemsAiError("GEMS AI contract assets are not installed")


def project_path(value: str) -> Path:
    return Path(value).expanduser().resolve()


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="gems-ai")
    root.add_argument("--version", action="version", version=__version__)
    commands = root.add_subparsers(dest="command", required=True)

    for name in ("inspect", "plan", "apply", "update", "check"):
        command = commands.add_parser(name)
        command.add_argument("--project", required=True)
        if name in {"plan", "apply", "update"}:
            command.add_argument("--task", default="governance")
        if name in {"apply", "update"}:
            command.add_argument("--dry-run", action="store_true")
        if name == "apply":
            command.add_argument("--version", required=True)
        if name == "update":
            command.add_argument("--to", default="2.0.0")
        if name == "check":
            command.add_argument("--strict", action="store_true")

    angular_gate = commands.add_parser("verify-angular")
    angular_gate.add_argument("--project", required=True)

    rollback_cmd = commands.add_parser("rollback")
    rollback_cmd.add_argument("--project", required=True)
    rollback_cmd.add_argument("--transaction", required=True)

    rules_cmd = commands.add_parser("rules")
    rules_sub = rules_cmd.add_subparsers(dest="rules_command", required=True)
    find = rules_sub.add_parser("find")
    bundle = rules_sub.add_parser("bundle")
    for command in (find, bundle):
        command.add_argument("--project", required=True)
        command.add_argument("--task", required=True)
        command.add_argument("--profile", choices=["java", "angular", "workspace"])
    bundle.add_argument("--format", choices=["list", "markdown", "json"], default="list")
    explain = rules_sub.add_parser("explain")
    explain.add_argument("--rule", required=True)

    round_cmd = commands.add_parser("round")
    round_sub = round_cmd.add_subparsers(dest="round_command", required=True)
    for name in ("status", "validate", "checkpoint", "sync"):
        command = round_sub.add_parser(name)
        command.add_argument("--project", required=True)
    init_cmd = round_sub.add_parser("init")
    init_cmd.add_argument("--project", required=True)
    init_cmd.add_argument("--slug", required=True)
    advance_cmd = round_sub.add_parser("advance")
    advance_cmd.add_argument("--project", required=True)
    advance_cmd.add_argument("--approved-by", required=True)
    advance_cmd.add_argument("--approval-evidence", required=True)
    close_cmd = round_sub.add_parser("close")
    close_cmd.add_argument("--project", required=True)
    close_cmd.add_argument("--outcome", choices=["completed", "blocked"], required=True)
    close_cmd.add_argument("--blocker")
    close_cmd.add_argument("--cause-type", choices=["external"])
    close_cmd.add_argument("--owner")
    close_cmd.add_argument("--evidence")
    close_cmd.add_argument("--resume-when")
    return root


def emit(value) -> None:
    if isinstance(value, str):
        print(value)
    else:
        print(json.dumps(value, indent=2, ensure_ascii=False))


def run(args: argparse.Namespace):
    root = sdk_root()
    if args.command == "inspect":
        return inspect(project_path(args.project))
    if args.command == "plan":
        project = project_path(args.project)
        config = read_config(project)
        return {"files": planned_files(root, project, Catalog(root), config["profile"], args.task)}
    if args.command == "apply":
        if args.version != "2.0.0":
            raise GemsAiError("only candidate version 2.0.0 is available")
        return apply(root, project_path(args.project), dry_run=args.dry_run, task=args.task)
    if args.command == "update":
        if args.to != "2.0.0":
            raise GemsAiError("only candidate version 2.0.0 is available")
        return apply(root, project_path(args.project), dry_run=args.dry_run, task=args.task)
    if args.command == "check":
        return check(project_path(args.project), strict=args.strict)
    if args.command == "verify-angular":
        return verify_angular(project_path(args.project))
    if args.command == "rollback":
        return rollback(project_path(args.project), args.transaction)
    if args.command == "rules":
        catalog = Catalog(root)
        if args.rules_command == "explain":
            rule = catalog.by_id(args.rule)
            return {**rule.__dict__, "content": (root / rule.path).read_text(encoding="utf-8")}
        project = project_path(args.project)
        profile = args.profile or read_config(project)["profile"]
        selected = catalog.select(profile, args.task)
        if args.rules_command == "find":
            return [{"id": rule.id, "path": rule.path} for rule in selected]
        if args.format == "json":
            return [{"id": rule.id, "content": (root / rule.path).read_text(encoding="utf-8")} for rule in selected]
        if args.format == "markdown":
            return "\n\n".join((root / rule.path).read_text(encoding="utf-8") for rule in selected)
        return "\n".join(rule.id for rule in selected)
    if args.command == "round":
        project = project_path(args.project)
        if args.round_command == "init":
            return rounds.init(project, args.slug)
        if args.round_command == "status":
            return rounds.load(project)
        if args.round_command == "validate":
            return rounds.validate(project)
        if args.round_command == "checkpoint":
            return rounds.checkpoint(project)
        if args.round_command == "advance":
            return rounds.advance(project, args.approved_by, args.approval_evidence)
        if args.round_command == "sync":
            return rounds.sync(project)
        return rounds.close(project, args.outcome, args.blocker, args.owner, args.evidence,
                            args.resume_when, args.cause_type)
    raise AssertionError("unhandled command")


def main(argv: list[str] | None = None) -> int:
    try:
        emit(run(parser().parse_args(argv)))
        return 0
    except GemsAiError as exc:
        print(str(exc), file=sys.stderr)
        return exc.exit_code


if __name__ == "__main__":
    raise SystemExit(main())
