class GemsAiError(Exception):
    exit_code = 20


class DriftError(GemsAiError):
    exit_code = 10


class ConfigurationError(GemsAiError):
    exit_code = 20


class ContentConflictError(GemsAiError):
    exit_code = 30


class GateError(GemsAiError):
    exit_code = 40


class InfrastructureError(GemsAiError):
    exit_code = 50
