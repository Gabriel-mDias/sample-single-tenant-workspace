from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from .errors import ConfigurationError

STATE = "estado-rodada.json"
CANONICAL = "round.md"
PHASES = ("discovery", "specification", "plan", "tasks", "execution", "validation")
ARTIFACTS = ("discovery.md", "spec.md", "plan.md", "tasks.md", "execution.md", "validation.md")
TERMINAL = {"completed", "blocked"}
SLUG = re.compile(r"^[a-z0-9][a-z0-9-]*$")
FENCE = re.compile(r"\A# GEMS SDD round\n\n```json\n(.*?)\n```\n\Z", re.DOTALL)


def _directory(project: Path) -> Path:
    return project / ".gems-ai" / "round"


def _path(project: Path) -> Path:
    return _directory(project) / STATE


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _record(project: Path, name: str) -> dict:
    if not isinstance(name, str) or not name or Path(name).is_absolute():
        raise ConfigurationError("artifact path must be project-relative")
    root = project.resolve()
    path = (root / name).resolve()
    if not path.is_relative_to(root) or path.is_relative_to(_directory(project).resolve()) or not path.is_file() or not path.read_text(encoding="utf-8").strip():
        raise ConfigurationError(f"artifact missing, empty, or outside project: {name}")
    return {"path": name, "sha256": _hash(path)}


def _read_canonical(project: Path) -> dict:
    path = _directory(project) / CANONICAL
    if not path.is_file():
        raise ConfigurationError("canonical round.md missing; legacy rounds require explicit migration")
    match = FENCE.fullmatch(path.read_text(encoding="utf-8"))
    if not match:
        raise ConfigurationError("invalid canonical round.md")
    try:
        value = json.loads(match.group(1))
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"invalid canonical round.md: {exc}") from exc
    if not isinstance(value, dict):
        raise ConfigurationError("canonical round must be an object")
    return value


def _projection(project: Path, value: dict) -> dict:
    if value.get("schemaVersion") != 2 or not isinstance(value.get("slug"), str) or not SLUG.fullmatch(value["slug"]):
        raise ConfigurationError("invalid round version or slug")
    steps = value.get("steps")
    if not isinstance(steps, list) or len(steps) > len(PHASES):
        raise ConfigurationError("invalid round steps")
    for index, step in enumerate(steps):
        if not isinstance(step, dict) or step.get("phase") != PHASES[index]:
            raise ConfigurationError("round phases must be sequential")
        for field in ("artifact", "approvalEvidence"):
            record = step.get(field)
            if not isinstance(record, dict) or not isinstance(record.get("sha256"), str):
                raise ConfigurationError(f"missing {field} record")
            if field == "artifact" and record.get("path") != ARTIFACTS[index]:
                raise ConfigurationError("wrong phase artifact")
            if _record(project, record.get("path")) != record:
                raise ConfigurationError(f"{field} hash diverged for {record.get('path')}")
        if step["artifact"]["path"] == step["approvalEvidence"]["path"]:
            raise ConfigurationError("approval evidence must be separate from the phase artifact")
        if not isinstance(step.get("approvedBy"), str) or not step["approvedBy"].strip():
            raise ConfigurationError("human approval actor missing")
    outcome = value.get("outcome")
    if outcome not in (None, *TERMINAL):
        raise ConfigurationError("invalid round outcome")
    if outcome == "completed" and len(steps) != len(PHASES):
        raise ConfigurationError("completed round requires all phases")
    if outcome == "blocked":
        blocker = value.get("blocker")
        if not isinstance(blocker, dict) or blocker.get("causeType") != "external":
            raise ConfigurationError("blocked round requires external cause")
        for field in ("cause", "owner", "resumeWhen"):
            if not isinstance(blocker.get(field), str) or not blocker[field].strip():
                raise ConfigurationError(f"blocked round requires {field}")
        record = blocker.get("evidence")
        if not isinstance(record, dict) or _record(project, record.get("path")) != record:
            raise ConfigurationError("blocked round requires current evidence")
    if outcome != "blocked" and "blocker" in value:
        raise ConfigurationError("unexpected blocker")
    phase = "closed" if outcome else (PHASES[len(steps)] if len(steps) < len(PHASES) else "closure")
    return {"schemaVersion": 2, "slug": value["slug"], "phase": phase,
            "outcome": outcome, "checkpoint": None if outcome else "human_approval",
            "steps": steps, **({"blocker": value["blocker"]} if outcome == "blocked" else {})}


def _write(project: Path, value: dict) -> dict:
    projection = _projection(project, value)
    directory = _directory(project)
    directory.mkdir(parents=True, exist_ok=True)
    (directory / CANONICAL).write_text("# GEMS SDD round\n\n```json\n" +
        json.dumps(value, indent=2, ensure_ascii=False) + "\n```\n", encoding="utf-8")
    _path(project).write_text(json.dumps(projection, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return projection


def load(project: Path) -> dict:
    state = _path(project)
    if not state.is_file():
        raise ConfigurationError("no active round")
    try:
        stored = json.loads(state.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"invalid round state: {exc}") from exc
    projected = _projection(project, _read_canonical(project))
    if stored != projected:
        raise ConfigurationError("round state diverged from canonical Markdown; run round sync")
    return projected


def init(project: Path, slug: str) -> dict:
    if not isinstance(slug, str) or not SLUG.fullmatch(slug):
        raise ConfigurationError("invalid round slug")
    if _path(project).exists() or (_directory(project) / CANONICAL).exists():
        raise ConfigurationError("round already exists; archive or migrate it explicitly")
    return _write(project, {"schemaVersion": 2, "slug": slug, "steps": [], "outcome": None})


def validate(project: Path) -> dict:
    value = load(project)
    return {"valid": True, "phase": value["phase"], "outcome": value["outcome"]}


def checkpoint(project: Path) -> dict:
    value = load(project)
    return {"slug": value["slug"], "phase": value["phase"], "checkpoint": value["checkpoint"]}


def advance(project: Path, approved_by: str, approval_evidence: str) -> dict:
    load(project)
    value = _read_canonical(project)
    index = len(value["steps"])
    if value["outcome"] or index >= len(PHASES):
        raise ConfigurationError("round has no phase to advance")
    if not approved_by or not approved_by.strip():
        raise ConfigurationError("explicit human approval actor required")
    if approval_evidence == ARTIFACTS[index]:
        raise ConfigurationError("approval evidence must be separate from the phase artifact")
    value["steps"].append({"phase": PHASES[index], "artifact": _record(project, ARTIFACTS[index]),
                           "approvedBy": approved_by.strip(), "approvalEvidence": _record(project, approval_evidence)})
    return _write(project, value)


def sync(project: Path) -> dict:
    if not _path(project).is_file():
        raise ConfigurationError("round state missing; legacy rounds require explicit migration")
    return _write(project, _read_canonical(project))


def close(project: Path, outcome: str, blocker: str | None = None, owner: str | None = None,
          evidence: str | None = None, resume_when: str | None = None, cause_type: str | None = None) -> dict:
    if outcome not in TERMINAL:
        raise ConfigurationError("outcome must be completed or blocked")
    load(project)
    value = _read_canonical(project)
    if value["outcome"]:
        raise ConfigurationError("round already closed")
    if outcome == "completed" and len(value["steps"]) != len(PHASES):
        raise ConfigurationError("cannot complete before validation checkpoint")
    if outcome == "blocked":
        if cause_type != "external" or not all(isinstance(v, str) and v.strip() for v in (blocker, owner, evidence, resume_when)):
            raise ConfigurationError("blocked requires external cause, owner, evidence and resumption condition")
        value["blocker"] = {"causeType": cause_type, "cause": blocker.strip(), "owner": owner.strip(),
                            "evidence": _record(project, evidence), "resumeWhen": resume_when.strip()}
    value["outcome"] = outcome
    return _write(project, value)
