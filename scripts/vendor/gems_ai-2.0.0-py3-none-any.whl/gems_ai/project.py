from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
from datetime import date, datetime, timezone
from pathlib import Path

from .catalog import Catalog
from .errors import ConfigurationError, ContentConflictError, DriftError

CONFIG = "gems-ai.json"
LOCK = "gems-ai.lock.json"
MANAGED_BEGIN = "<!-- GEMS-AI:BEGIN -->"
MANAGED_END = "<!-- GEMS-AI:END -->"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def text_sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def read_config(project: Path) -> dict:
    path = project / CONFIG
    if not path.is_file():
        raise ConfigurationError(f"{CONFIG} not found in {project}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"invalid {CONFIG}: {exc}") from exc
    if not isinstance(value, dict):
        raise ConfigurationError(f"{CONFIG} must be an object")
    unknown = sorted(set(value) - {"version", "commit", "profile", "waivers", "localAssertions"})
    if unknown:
        raise ConfigurationError(f"unsupported configuration fields: {', '.join(unknown)}")
    commit = value.get("commit", "")
    if value.get("version") != "2.0.0" or value.get("profile") not in {"java", "angular", "workspace"} or not isinstance(commit, str) or len(commit) != 40 or any(char not in "0123456789abcdef" for char in commit):
        raise ConfigurationError("configuration requires version 2.0.0, a 40-character lowercase commit, and profile java|angular|workspace")
    return value


# Deliberately narrow, machine-checkable claims. Prose outside this vocabulary
# still needs human review; it is not silently classified as conformant.
CANONICAL_ASSERTIONS = {
    ("base.precedence", "base-rules-loaded"): True,
    ("base.precedence", "base-rules-cannot-be-weakened"): True,
    ("base.waivers", "waiver-requires-approval"): True,
}


def validate_assertions(assertions: list[dict]) -> None:
    if not isinstance(assertions, list):
        raise ConfigurationError("localAssertions must be an array")
    seen = set()
    for index, assertion in enumerate(assertions):
        if not isinstance(assertion, dict) or set(assertion) != {"rule", "claim", "value"}:
            raise ConfigurationError(f"local assertion {index} requires rule, claim and value")
        if not isinstance(assertion["rule"], str) or not isinstance(assertion["claim"], str):
            raise ConfigurationError(f"local assertion {index} rule and claim must be strings")
        key = (assertion["rule"], assertion["claim"])
        if key not in CANONICAL_ASSERTIONS or type(assertion["value"]) is not bool:
            raise ConfigurationError(f"unsupported local assertion: {key}")
        if key in seen:
            raise ConfigurationError(f"duplicate local assertion: {key}")
        seen.add(key)
        if assertion["value"] != CANONICAL_ASSERTIONS[key]:
            raise ConfigurationError(f"local assertion contradicts {key[0]}:{key[1]}")


def validate_waivers(waivers: list[dict], known_rule_ids: set[str]) -> None:
    required = {"rule", "scope", "justification", "owner", "expires", "compensation", "approvedBy"}
    if not isinstance(waivers, list):
        raise ConfigurationError("waivers must be an array")
    for index, waiver in enumerate(waivers):
        if not isinstance(waiver, dict):
            raise ConfigurationError(f"waiver {index} must be an object")
        missing = sorted(required - waiver.keys())
        if missing:
            raise ConfigurationError(f"waiver {index} missing: {', '.join(missing)}")
        unknown = sorted(waiver.keys() - required)
        if unknown:
            raise ConfigurationError(f"waiver {index} has unsupported fields: {', '.join(unknown)}")
        for field in sorted(required):
            if not isinstance(waiver[field], str) or not waiver[field].strip():
                raise ConfigurationError(f"waiver {index} requires non-empty string: {field}")
        if waiver["rule"] not in known_rule_ids:
            raise ConfigurationError(f"waiver references unknown rule: {waiver['rule']}")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", waiver["expires"]):
            raise ConfigurationError(f"waiver has invalid expiry: {waiver['expires']}")
        try:
            expires = date.fromisoformat(waiver["expires"])
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"waiver has invalid expiry: {waiver['expires']}") from exc
        if expires < date.today():
            raise ConfigurationError(f"waiver expired: {waiver['rule']} on {expires.isoformat()}")


def inspect(project: Path) -> dict:
    return {
        "project": str(project.resolve()),
        "hasMaven": (project / "pom.xml").exists() or (project / "backend" / "pom.xml").exists(),
        "hasAngular": (project / "angular.json").exists() or (project / "frontend" / "angular.json").exists(),
        "configured": (project / CONFIG).is_file(),
        "locked": (project / LOCK).is_file(),
    }


def planned_files(root: Path, project: Path, catalog: Catalog, profile: str, task: str) -> list[dict]:
    selected_ids = {rule.id for rule in catalog.select(profile, task)}
    result = []
    snapshot_rules = sorted(
        (rule for rule in catalog.rules if rule.mandatory or profile in rule.profiles),
        key=lambda rule: (rule.precedence, rule.id),
    )
    for rule in snapshot_rules:
        source = root / rule.path
        target = project / ".gems-ai" / "rules" / f"{rule.id}.md"
        result.append({"kind": "rule", "rule": rule.id, "selected": rule.id in selected_ids, "source": str(source), "target": str(target), "sha256": sha256(source)})
    return result


def snapshot_assets(root: Path, project: Path) -> list[dict]:
    result = []
    catalog = root / "contract" / "catalog.json"
    result.append({"kind": "catalog", "source": str(catalog), "target": str(project / ".gems-ai" / "catalog.json"), "sha256": sha256(catalog)})
    version = root / "contract" / "VERSION"
    result.append({"kind": "version", "source": str(version), "target": str(project / ".gems-ai" / ".version"), "sha256": sha256(version)})
    for source in sorted((root / "schemas").glob("*.json")):
        target = project / ".gems-ai" / "schemas" / source.name
        result.append({"kind": "schema", "source": str(source), "target": str(target), "sha256": sha256(source)})
    for skill_name in ("gems-ai-sdk", "rodada-sdd"):
        skill_root = root / "skills" / skill_name
        for source in sorted(path for path in skill_root.rglob("*") if path.is_file()):
            target = project / ".agents" / "skills" / skill_name / source.relative_to(skill_root)
            result.append({"kind": "skill", "source": str(source), "target": str(target), "sha256": sha256(source)})
    return result


def _managed_adapter(current: str, block: str) -> str:
    rendered = f"{MANAGED_BEGIN}\n{block.rstrip()}\n{MANAGED_END}"
    if MANAGED_BEGIN not in current and MANAGED_END not in current:
        return f"{current.rstrip()}\n\n{rendered}\n" if current.strip() else f"{rendered}\n"
    if current.count(MANAGED_BEGIN) != 1 or current.count(MANAGED_END) != 1:
        raise ContentConflictError("adapter has malformed managed markers")
    before, remainder = current.split(MANAGED_BEGIN, 1)
    _, after = remainder.split(MANAGED_END, 1)
    return f"{before}{rendered}{after}"


def _extract_managed_adapter(current: str) -> str | None:
    begin_count = current.count(MANAGED_BEGIN)
    end_count = current.count(MANAGED_END)
    if begin_count == end_count == 0:
        return None
    if begin_count != 1 or end_count != 1:
        raise ContentConflictError("adapter has malformed managed markers")
    before, remainder = current.split(MANAGED_BEGIN, 1)
    managed, after = remainder.split(MANAGED_END, 1)
    del before, after
    return f"{MANAGED_BEGIN}{managed}{MANAGED_END}"


def apply(root: Path, project: Path, *, dry_run: bool = False, task: str = "governance") -> dict:
    config = read_config(project)
    catalog = Catalog(root)
    validate_waivers(config.get("waivers", []), {rule.id for rule in catalog.rules})
    validate_assertions(config.get("localAssertions", []))
    if (project / LOCK).is_file():
        check(project, _allow_manifest_change=True)
    plan = planned_files(root, project, catalog, config["profile"], task)
    assets = snapshot_assets(root, project)
    deployment = plan + assets
    expected_rules = {Path(item["target"]).resolve() for item in plan}
    expected_assets = {Path(item["target"]).resolve() for item in assets}
    rules_root = project / ".gems-ai" / "rules"
    stale_rules = sorted(
        path for path in rules_root.rglob("*.md")
        if path.resolve() not in expected_rules
    ) if rules_root.is_dir() else []
    managed_asset_roots = (
        project / ".gems-ai" / "schemas",
        project / ".agents" / "skills" / "gems-ai-sdk",
        project / ".agents" / "skills" / "rodada-sdd",
    )
    stale_assets = sorted(
        path
        for managed_root in managed_asset_roots
        if managed_root.is_dir()
        for path in managed_root.rglob("*")
        if path.is_file() and path.resolve() not in expected_assets
    )
    stale_managed = stale_rules + stale_assets
    deletions = [
        {
            "kind": "delete",
            "target": str(path),
            "reason": "stale-rule-from-previous-snapshot" if path in stale_rules else "stale-managed-asset-from-previous-snapshot",
        }
        for path in stale_managed
    ]
    if dry_run:
        return {"changed": False, "dryRun": True, "files": deployment + deletions}

    adapter_block = (root / "adapters" / "managed-block.md").read_text(encoding="utf-8")
    rule_changes = any(
        not Path(item["target"]).exists() or sha256(Path(item["target"])) != item["sha256"]
        for item in deployment
    ) or bool(stale_managed)
    adapter_changes = False
    for name in ("AGENTS.md", "CLAUDE.md", "GEMINI.md"):
        target = project / name
        current = target.read_text(encoding="utf-8") if target.exists() else ""
        if _managed_adapter(current, adapter_block) != current:
            adapter_changes = True
    lock_changes = True
    if (project / LOCK).is_file():
        current_lock = json.loads((project / LOCK).read_text(encoding="utf-8"))
        lock_changes = any(
            current_lock.get(key) != config.get(key)
            for key in ("version", "commit", "profile")
        ) or current_lock.get("waivers", []) != config.get("waivers", []) or current_lock.get("localAssertions", []) != config.get("localAssertions", [])
    if not rule_changes and not adapter_changes and not lock_changes:
        status = check(project)
        return {"changed": False, "transaction": current_lock["transaction"], "status": status}

    transaction = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ%f")
    tx_root = project / ".gems-ai" / "transactions" / transaction
    backup = tx_root / "backup"
    managed_directories = {parent for item in deployment for parent in Path(item["target"]).parents if parent != project and project in parent.parents}
    managed_directories.update(parent for parent in backup.parents if parent != project and project in parent.parents)
    existing_directories = {path for path in managed_directories if path.is_dir()}
    staged = Path(tempfile.mkdtemp(prefix="gems-ai-", dir=project))
    changed: list[str] = []
    try:
        for item in deployment:
            target = Path(item["target"])
            staged_target = staged / target.relative_to(project)
            staged_target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item["source"], staged_target)
        for item in deployment:
            target = Path(item["target"])
            staged_target = staged / target.relative_to(project)
            if not target.exists() or target.read_bytes() != staged_target.read_bytes():
                if target.exists():
                    saved = backup / target.relative_to(project)
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, saved)
                target.parent.mkdir(parents=True, exist_ok=True)
                changed.append(str(target.relative_to(project)))
                shutil.copy2(staged_target, target)

        for target in stale_managed:
            saved = backup / target.relative_to(project)
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
            changed.append(str(target.relative_to(project)))
            target.unlink()

        for name in ("AGENTS.md", "CLAUDE.md", "GEMINI.md"):
            target = project / name
            current = target.read_text(encoding="utf-8") if target.exists() else ""
            updated = _managed_adapter(current, adapter_block)
            if updated != current:
                if target.exists():
                    saved = backup / name
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, saved)
                changed.append(name)
                target.write_text(updated, encoding="utf-8", newline="\n")

        lock = {
            "schemaVersion": 1,
            "version": "2.0.0",
            "commit": config["commit"],
            "profile": config["profile"],
            "transaction": transaction,
            "rules": [{"id": item["rule"], "path": str(Path(item["target"]).relative_to(project)), "sha256": item["sha256"]} for item in plan],
            "assets": [{"kind": item["kind"], "path": str(Path(item["target"]).relative_to(project)), "sha256": item["sha256"]} for item in assets],
            "adapters": [
                {
                    "path": name,
                    "managedSha256": text_sha256(_extract_managed_adapter((project / name).read_text(encoding="utf-8")) or "")
                }
                for name in ("AGENTS.md", "CLAUDE.md", "GEMINI.md")
            ],
            "waivers": config.get("waivers", []),
            "localAssertions": config.get("localAssertions", []),
        }
        lock_path = project / LOCK
        if lock_path.exists():
            saved = backup / LOCK
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(lock_path, saved)
        changed.append(LOCK)
        lock_path.write_text(json.dumps(lock, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
        tx_root.mkdir(parents=True, exist_ok=True)
        (tx_root / "transaction.json").write_text(json.dumps({"id": transaction, "changed": changed}, indent=2) + "\n", encoding="utf-8")
        return {"changed": bool(changed), "transaction": transaction, "files": changed}
    except Exception:
        for relative in reversed(changed):
            target = project / relative
            saved = backup / relative
            if saved.is_file():
                shutil.copy2(saved, target)
            elif target.exists():
                target.unlink()
        shutil.rmtree(tx_root, ignore_errors=True)
        for directory in sorted(managed_directories - existing_directories, key=lambda path: len(path.parts), reverse=True):
            if directory != staged and directory.exists() and not any(directory.iterdir()):
                directory.rmdir()
        raise
    finally:
        shutil.rmtree(staged, ignore_errors=True)


def check(project: Path, *, strict: bool = False, _allow_manifest_change: bool = False) -> dict:
    config = read_config(project)
    lock_path = project / LOCK
    if not lock_path.is_file():
        raise DriftError(f"{LOCK} not found")
    try:
        lock = json.loads(lock_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"invalid {LOCK}: {exc}") from exc
    drift = []
    for item in lock.get("rules", []) + lock.get("assets", []):
        path = project / item["path"]
        if not path.is_file() or sha256(path) != item["sha256"]:
            drift.append(item["path"])
    expected_rules = {str(Path(item["path"])) for item in lock.get("rules", [])}
    rules_root = project / ".gems-ai" / "rules"
    if rules_root.is_dir():
        actual_rules = {
            str(path.relative_to(project))
            for path in rules_root.rglob("*.md")
        }
        drift.extend(f"unexpected:{path}" for path in sorted(actual_rules - expected_rules))
    expected_assets = {str(Path(item["path"])) for item in lock.get("assets", [])}
    for managed_root in (
        project / ".gems-ai" / "schemas",
        project / ".agents" / "skills" / "gems-ai-sdk",
        project / ".agents" / "skills" / "rodada-sdd",
    ):
        if managed_root.is_dir():
            for path in managed_root.rglob("*"):
                if path.is_file():
                    relative = str(path.relative_to(project))
                    if relative not in expected_assets:
                        drift.append(f"unexpected:{relative}")
    for item in lock.get("adapters", []):
        if isinstance(item, str):
            drift.append(f"legacy-adapter-lock:{item}")
            continue
        path = project / item["path"]
        if not path.is_file():
            drift.append(item["path"])
            continue
        managed = _extract_managed_adapter(path.read_text(encoding="utf-8"))
        if managed is None or text_sha256(managed) != item["managedSha256"]:
            drift.append(item["path"])
    known_rules = {item["id"] for item in lock.get("rules", [])}
    validate_waivers(config.get("waivers", []), known_rules)
    validate_waivers(lock.get("waivers", []), known_rules)
    validate_assertions(config.get("localAssertions", []))
    validate_assertions(lock.get("localAssertions", []))
    if not _allow_manifest_change and any(
        config.get(field, [] if field in {"waivers", "localAssertions"} else None) != lock.get(field, [] if field in {"waivers", "localAssertions"} else None)
        for field in ("version", "commit", "profile", "waivers", "localAssertions")
    ):
        drift.append("manifest-lock-mismatch")
    if drift:
        raise DriftError("drift detected: " + ", ".join(drift))
    return {"status": "conformant", "scope": "snapshot_integrity", "rules": len(lock.get("rules", [])), "strict": strict}


def rollback(project: Path, transaction: str) -> dict:
    tx_root = project / ".gems-ai" / "transactions" / transaction
    record_path = tx_root / "transaction.json"
    if not record_path.is_file():
        raise ConfigurationError(f"unknown transaction: {transaction}")
    record = json.loads(record_path.read_text(encoding="utf-8"))
    restored = []
    for relative in reversed(record.get("changed", [])):
        target = project / relative
        saved = tx_root / "backup" / relative
        if saved.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved, target)
        elif target.exists():
            target.unlink()
        restored.append(relative)
    return {"transaction": transaction, "restored": restored}
