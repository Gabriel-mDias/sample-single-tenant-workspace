from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from .errors import ConfigurationError


@dataclass(frozen=True)
class Rule:
    id: str
    title: str
    version: str
    status: str
    path: str
    mandatory: bool
    profiles: tuple[str, ...]
    tasks: tuple[str, ...]
    risk: str
    precedence: int
    related_rules: tuple[str, ...]
    required_rules: tuple[str, ...]
    required_gates: tuple[str, ...]

    @classmethod
    def from_dict(cls, value: dict) -> "Rule":
        required = {"id", "title", "version", "status", "path", "mandatory", "profiles", "tasks", "risk", "precedence", "related_rules", "required_gates"}
        missing = sorted(required - value.keys())
        if missing:
            raise ConfigurationError(f"rule metadata missing: {', '.join(missing)}")
        return cls(
            id=value["id"],
            title=value["title"],
            version=value["version"],
            status=value["status"],
            path=value["path"],
            mandatory=bool(value["mandatory"]),
            profiles=tuple(value["profiles"]),
            tasks=tuple(value["tasks"]),
            risk=value["risk"],
            precedence=int(value["precedence"]),
            related_rules=tuple(value["related_rules"]),
            required_rules=tuple(value.get("required_rules", [])),
            required_gates=tuple(value["required_gates"]),
        )


class Catalog:
    def __init__(self, root: Path):
        self.root = root
        path = root / "contract" / "catalog.json"
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ConfigurationError(f"invalid catalog: {exc}") from exc
        if raw.get("version") != "2.0.0":
            raise ConfigurationError("catalog version must be 2.0.0")
        self.rules = tuple(Rule.from_dict(item) for item in raw.get("rules", []))
        ids = [rule.id for rule in self.rules]
        if len(ids) != len(set(ids)):
            raise ConfigurationError("catalog contains duplicate rule ids")
        for rule in self.rules:
            path = root / rule.path
            if not path.is_file():
                raise ConfigurationError(f"rule path does not exist: {rule.path}")
            first_line = path.read_text(encoding="utf-8").splitlines()[0]
            match = re.fullmatch(r"<!-- gems-ai-rule: (\{.*\}) -->", first_line)
            if not match:
                raise ConfigurationError(f"rule metadata marker missing: {rule.path}")
            try:
                embedded = json.loads(match.group(1))
            except json.JSONDecodeError as exc:
                raise ConfigurationError(f"invalid rule metadata marker: {rule.path}") from exc
            if (embedded.get("id"), embedded.get("version"), embedded.get("status")) != (rule.id, rule.version, rule.status):
                raise ConfigurationError(f"rule metadata marker diverges from catalog: {rule.path}")
            unknown_related = sorted(set(rule.related_rules) - set(ids))
            if unknown_related:
                raise ConfigurationError(f"unknown related rules for {rule.id}: {', '.join(unknown_related)}")
            unknown_required = sorted(set(rule.required_rules) - set(ids))
            if unknown_required:
                raise ConfigurationError(f"unknown required rules for {rule.id}: {', '.join(unknown_required)}")

    def select(self, profile: str, task: str) -> tuple[Rule, ...]:
        if profile not in {"java", "angular", "workspace"}:
            raise ConfigurationError(f"unknown profile '{profile}'")
        known_tasks = {item for rule in self.rules if not rule.mandatory for item in rule.tasks}
        if task not in known_tasks:
            raise ConfigurationError(f"unknown task '{task}'; classify it before routing")
        selected = {rule.id for rule in self.rules if rule.mandatory or (profile in rule.profiles and task in rule.tasks)}
        visiting: set[str] = set()

        def require(rule_id: str) -> None:
            if rule_id in visiting:
                raise ConfigurationError(f"required rule cycle at {rule_id}")
            rule = self.by_id(rule_id)
            if not rule.mandatory and profile not in rule.profiles:
                raise ConfigurationError(f"required rule {rule_id} is unavailable for profile {profile}")
            visiting.add(rule_id)
            for dependency in rule.required_rules:
                selected.add(dependency)
                require(dependency)
            visiting.remove(rule_id)

        for rule_id in tuple(selected):
            require(rule_id)
        return tuple(sorted((rule for rule in self.rules if rule.id in selected), key=lambda rule: (rule.precedence, rule.id)))

    def by_id(self, rule_id: str) -> Rule:
        for rule in self.rules:
            if rule.id == rule_id:
                return rule
        raise ConfigurationError(f"unknown rule: {rule_id}")
